# Enterprise AI Lead Master Prompt Library

## Recommended Format

The most maintainable format is:

1. **One Markdown file per prompt** for clean version control, focused editing, and easy reuse as a system prompt.
2. **YAML front matter** for prompt ID, version, role, and tags.
3. **A shared context template** so project details are not duplicated across prompts.
4. **A combined library file** for full-text search and offline reference.
5. **A ZIP archive** for convenient download and sharing.

## How to Use

- Open `00_SHARED_CONTEXT_TEMPLATE.md` and fill in the current project details.
- Choose the relevant prompt file.
- Use that prompt as the system instruction.
- Provide only the evidence relevant to the task.
- Keep unknown information marked as `UNKNOWN`.
- Version prompts in Git when they become part of team process.

## Prompt Index

1. [Technical Design and ADR Generator](01_TECHNICAL_DESIGN_ADR_GENERATOR.md)
2. [Pull Request and Code Review Gatekeeper](02_PULL_REQUEST_CODE_REVIEW_GATEKEEPER.md)
3. [Production Readiness Reviewer](03_PRODUCTION_READINESS_REVIEWER.md)
4. [AI Evaluation and Quality Engineer](04_AI_EVALUATION_QUALITY_ENGINEER.md)
5. [Observability and Incident Prevention Architect](05_OBSERVABILITY_INCIDENT_PREVENTION_ARCHITECT.md)
6. [Sprint and Technical Execution Planner](06_SPRINT_TECHNICAL_EXECUTION_PLANNER.md)
7. [Requirement Ambiguity and Gap Analyzer](07_REQUIREMENT_AMBIGUITY_GAP_ANALYZER.md)
8. [Technical Debt Prioritization Advisor](08_TECHNICAL_DEBT_PRIORITIZATION_ADVISOR.md)
9. [Dependency and Framework Upgrade Planner](09_DEPENDENCY_FRAMEWORK_UPGRADE_PLANNER.md)
10. [Meeting-to-Decision and Action Generator](10_MEETING_TO_DECISION_ACTION_GENERATOR.md)
11. [RAG Optimization Architect](11_RAG_OPTIMIZATION_ARCHITECT.md)
12. [Agent Workflow Safety and Efficiency Reviewer](12_AGENT_WORKFLOW_SAFETY_EFFICIENCY_REVIEWER.md)
13. [Prompt Engineering and Prompt Regression Manager](13_PROMPT_ENGINEERING_REGRESSION_MANAGER.md)
14. [Model and Technology Selection Advisor](14_MODEL_TECHNOLOGY_SELECTION_ADVISOR.md)
15. [AI Cost and Token Optimization Auditor](15_AI_COST_TOKEN_OPTIMIZATION_AUDITOR.md)
16. [Engineering Risk Register Generator](16_ENGINEERING_RISK_REGISTER_GENERATOR.md)
17. [Team Ownership and RACI Architect](17_TEAM_OWNERSHIP_RACI_ARCHITECT.md)
18. [Executive Architecture Brief Generator](18_EXECUTIVE_ARCHITECTURE_BRIEF_GENERATOR.md)
19. [Vendor and Build-versus-Buy Evaluator](19_VENDOR_BUILD_VS_BUY_EVALUATOR.md)
20. [Post-Incident Review Generator](20_POST_INCIDENT_REVIEW_GENERATOR.md)

## Suggested Daily Set

- Pull Request and Code Review Gatekeeper
- Requirement Ambiguity and Gap Analyzer
- Sprint and Technical Execution Planner
- Meeting-to-Decision and Action Generator

## Suggested Release Set

- Technical Design and ADR Generator
- Production Readiness Reviewer
- Observability and Incident Prevention Architect
- AI Evaluation and Quality Engineer

## Suggested AI Architecture Set

- RAG Optimization Architect
- Agent Workflow Safety and Efficiency Reviewer
- Prompt Engineering and Prompt Regression Manager
- Model and Technology Selection Advisor
- AI Cost and Token Optimization Auditor

## Suggested Leadership Set

- Technical Debt Prioritization Advisor
- Engineering Risk Register Generator
- Team Ownership and RACI Architect
- Executive Architecture Brief Generator
- Vendor and Build-versus-Buy Evaluator
- Post-Incident Review Generator
