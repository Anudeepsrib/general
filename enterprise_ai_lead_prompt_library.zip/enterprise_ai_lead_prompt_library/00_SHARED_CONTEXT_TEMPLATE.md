# Shared Context Template

Use this block before any master prompt when the task depends on the current project.

```yaml
project_name: "{{PROJECT_NAME}}"
business_domain: "{{BUSINESS_DOMAIN}}"
business_goal: "{{BUSINESS_GOAL}}"

users_and_personas:
  - "{{PERSONA_1}}"
  - "{{PERSONA_2}}"

architecture_summary: |
  {{CURRENT_ARCHITECTURE_SUMMARY}}

core_stack:
  backend: "Python, FastAPI"
  orchestration: "LangChain, LangGraph"
  search: "Azure AI Search"
  model_platform: "Azure AI Foundry / Azure OpenAI"
  deployment: "Azure Kubernetes Service"
  data_platform: "{{ADLS_DATABRICKS_SNOWFLAKE_OR_OTHER}}"
  observability: "{{APPLICATION_INSIGHTS_OPENTELEMETRY_OTHER}}"

service_level_objectives:
  availability: "{{AVAILABILITY_SLO}}"
  latency_p50: "{{P50_TARGET}}"
  latency_p95: "{{P95_TARGET}}"
  latency_p99: "{{P99_TARGET}}"
  error_rate: "{{ERROR_RATE_TARGET}}"

traffic_and_scale:
  sustained_rps: "{{SUSTAINED_RPS}}"
  peak_rps: "{{PEAK_RPS}}"
  peak_concurrency: "{{PEAK_CONCURRENCY}}"
  tenants: "{{TENANT_COUNT}}"
  users: "{{USER_COUNT}}"
  data_volume: "{{DATA_VOLUME}}"

dependencies:
  databases:
    - "{{DATABASE}}"
  caches:
    - "{{CACHE}}"
  queues:
    - "{{QUEUE_OR_WORKFLOW_ENGINE}}"
  external_apis:
    - "{{EXTERNAL_API}}"
  ai_services:
    - "{{MODEL_OR_SEARCH_SERVICE}}"

security_and_compliance:
  data_classification: "{{PUBLIC_INTERNAL_CONFIDENTIAL_RESTRICTED}}"
  tenant_isolation: "{{TENANT_MODEL}}"
  regulatory_requirements:
    - "{{REQUIREMENT}}"
  authentication: "{{AUTHENTICATION_MODEL}}"
  authorization: "{{AUTHORIZATION_MODEL}}"

delivery_constraints:
  deadline: "{{DEADLINE}}"
  team_capacity: "{{TEAM_CAPACITY}}"
  budget: "{{BUDGET_CONSTRAINT}}"
  backward_compatibility: "{{COMPATIBILITY_REQUIREMENT}}"

known_problems:
  - "{{KNOWN_PROBLEM}}"

available_evidence:
  - "{{REPOSITORY_OR_FILES}}"
  - "{{ARCHITECTURE_DIAGRAMS}}"
  - "{{TRACES_METRICS_LOGS}}"
  - "{{TICKETS_REQUIREMENTS}}"
  - "{{LOAD_TEST_RESULTS}}"
```

## Usage

- Replace placeholders with known values.
- Keep unknown values as `UNKNOWN`.
- Do not invent missing production metrics.
- Attach only the files needed for the specific review.
- Remove secrets, tokens, private keys, personal data, and unrelated confidential information.
